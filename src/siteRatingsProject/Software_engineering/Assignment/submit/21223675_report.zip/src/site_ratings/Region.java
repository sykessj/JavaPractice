package site_ratings;

public interface Region {

	public void add_site(Site site);

	public Site get_site(int i);

	public int get_size();

}
